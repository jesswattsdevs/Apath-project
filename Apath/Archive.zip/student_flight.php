<?php
include "helpers.php";
include "connection.php";
require_login(array(2));

$currentPage = "flight";
$studentId = (int) $_SESSION["user_id"];
$leavingFlightNumber = "";
$leavingAirlineName = "";
$leavingDate = "";
$leavingTime = "";

$leavingFlightNumberErr = "";
$leavingAirlineNameErr = "";
$leavingDateErr = "";
$leavingTimeErr = "";
$successMessage = "";

$loadSql = "SELECT * FROM apath_student WHERE s_id=$studentId";
$loadResult = mysqli_query($dbc, $loadSql);
if ($loadResult && mysqli_num_rows($loadResult) === 1) {
    $row = mysqli_fetch_assoc($loadResult);
    $leavingFlightNumber = $row["leaving_flight_number"];
    $leavingAirlineName = $row["leaving_airline_name"];
    $leavingDate = $row["leaving_date"];
    $leavingTime = $row["leaving_time"];
}

if (($_SERVER["REQUEST_METHOD"] ?? "") === "POST") {
    $leavingFlightNumber = test_input($_POST["leaving_flight_number"] ?? "");
    $leavingAirlineName = test_input($_POST["leaving_airline_name"] ?? "");
    $leavingDate = test_input($_POST["leaving_date"] ?? "");
    $leavingTime = test_input($_POST["leaving_time"] ?? "");
    $hasError = false;

    if ($leavingFlightNumber === "") {
        $leavingFlightNumberErr = "Leaving flight number is required.";
        $hasError = true;
    }

    if ($leavingAirlineName === "") {
        $leavingAirlineNameErr = "Leaving airline name is required.";
        $hasError = true;
    }

    if ($leavingDate === "") {
        $leavingDateErr = "Leaving date is required.";
        $hasError = true;
    }

    if ($leavingTime === "") {
        $leavingTimeErr = "Leaving time is required.";
        $hasError = true;
    }

    if (!$hasError) {
        upsert_student_shell($dbc, $studentId, $_SESSION["user_email"]);
        $safeFlight = mysqli_real_escape_string($dbc, $leavingFlightNumber);
        $safeAirline = mysqli_real_escape_string($dbc, $leavingAirlineName);
        $safeDate = mysqli_real_escape_string($dbc, $leavingDate);
        $safeTime = mysqli_real_escape_string($dbc, $leavingTime);
        $sql = "UPDATE apath_student
                SET leaving_flight_number='$safeFlight', leaving_airline_name='$safeAirline', leaving_date='$safeDate', leaving_time='$safeTime'
                WHERE s_id=$studentId";
        mysqli_query($dbc, $sql);
        $successMessage = "Flight information submitted successfully.";
    }
}
?>
<html>
<head>
    <title>Lab 7 - Student Flight Information</title>
    <?php include "student_styles.php"; ?>
</head>
<body>
    <div class="page-shell">
        <div class="hero">
            <div class="hero-inner">
                <h1>APATH</h1>
                <p class="subtitle">Student Flight Information</p>
                <?php include "student_nav.php"; ?>
                <?php if ($successMessage !== "") { ?><div class="success"><?php echo $successMessage; ?></div><?php } ?>
                <section class="panel">
                    <h2>Flight Form</h2>
                    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                        <div class="row">
                            <label for="leaving_flight_number">Leaving Flight Number <span class="required">*</span></label>
                            <input type="text" id="leaving_flight_number" name="leaving_flight_number" value="<?php echo $leavingFlightNumber; ?>">
                            <?php if ($leavingFlightNumberErr !== "") { ?><div class="error"><?php echo $leavingFlightNumberErr; ?></div><?php } ?>
                        </div>

                        <div class="row">
                            <label for="leaving_airline_name">Leaving Airline Name <span class="required">*</span></label>
                            <input type="text" id="leaving_airline_name" name="leaving_airline_name" value="<?php echo $leavingAirlineName; ?>">
                            <?php if ($leavingAirlineNameErr !== "") { ?><div class="error"><?php echo $leavingAirlineNameErr; ?></div><?php } ?>
                        </div>

                        <div class="row">
                            <label for="leaving_date">Leaving Date <span class="required">*</span></label>
                            <input type="text" id="leaving_date" name="leaving_date" placeholder="MM/DD/YYYY" value="<?php echo $leavingDate; ?>">
                            <?php if ($leavingDateErr !== "") { ?><div class="error"><?php echo $leavingDateErr; ?></div><?php } ?>
                        </div>

                        <div class="row">
                            <label for="leaving_time">Leaving Time <span class="required">*</span></label>
                            <input type="text" id="leaving_time" name="leaving_time" placeholder="10:30 AM" value="<?php echo $leavingTime; ?>">
                            <?php if ($leavingTimeErr !== "") { ?><div class="error"><?php echo $leavingTimeErr; ?></div><?php } ?>
                        </div>

                        <div class="actions">
                            <input type="submit" value="Submit Flight Information">
                        </div>
                    </form>
                </section>
            </div>
        </div>
    </div>
</body>
</html>
