<?php
$currentPage = $currentPage ?? "";
?>
<div class="nav-links">
    <a href="volunteer_home.php" <?php if ($currentPage === "home") echo 'class="active"'; ?>>Home</a>
    <a href="volunteer_profile.php" <?php if ($currentPage === "profile") echo 'class="active"'; ?>>Personal Profile</a>
    <a href="volunteer_car.php" <?php if ($currentPage === "car") echo 'class="active"'; ?>>Car Information</a>
    <a href="logout.php">Logout</a>
</div>
