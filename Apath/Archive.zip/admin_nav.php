<?php
$currentPage = $currentPage ?? "";
?>
<div class="nav-links">
    <a href="admin_home.php" <?php if ($currentPage === "home") echo 'class="active"'; ?>>Home</a>
    <a href="manage_students.php" <?php if ($currentPage === "students") echo 'class="active"'; ?>>Manage Students</a>
    <a href="manage_volunteers.php" <?php if ($currentPage === "volunteers") echo 'class="active"'; ?>>Manage Volunteers</a>
    <a href="logout.php">Logout</a>
</div>
