<?php
include "helpers.php";
require_login(array(2));
$currentPage = "home";
?>
<html>
<head>
    <title>APATH Student Home</title>
    <?php include "student_styles.php"; ?>
</head>
<body>
    <div class="page-shell">
        <div class="hero">
            <div class="hero-inner">
                <h1>APATH</h1>
                <p class="subtitle">Student Home Page</p>
                <?php include "student_nav.php"; ?>
                <section class="panel">
                    <h2>Welcome to Atlanta GA</h2>
                    <p>Please complete your personal profile and flight information!</p>
                    <ul>
                    <li>If you need airport pickup, please provide your flight information</li>
                    <li>If you need temporary housing, please complete the temp housing need forms.</li>
                    <li>(Housing links are skipped for the main Phase 1 and 2) </li>
                        
                    </ul>
                </section>
            </div>
        </div>
    </div>
</body>
</html>
