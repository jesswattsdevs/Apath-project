<style>
    * {
        box-sizing: border-box;
    }

    body {
        margin: 0;
        font-family: Georgia, "Times New Roman", serif;
        background:
            linear-gradient(180deg, rgba(243, 247, 250, 0.96), rgba(221, 232, 238, 0.96)),
            repeating-linear-gradient(90deg, rgba(30, 57, 79, 0.04) 0, rgba(30, 57, 79, 0.04) 1px, transparent 1px, transparent 48px);
        color: #1d2d35;
    }

    .page-shell {
        max-width: 1100px;
        margin: 28px auto;
        padding: 24px;
    }

    .hero {
        background: linear-gradient(135deg, #f7fbfd 0%, #d9e7ee 55%, #c4d8e2 100%);
        border: 8px solid #f4ecec;
        border-radius: 24px;
        box-shadow: 0 24px 60px rgba(28, 47, 61, 0.18);
        overflow: hidden;
        position: relative;
    }

    .hero::after {
        content: "";
        position: absolute;
        left: -8%;
        right: -8%;
        bottom: -85px;
        height: 180px;
        background:
            radial-gradient(circle at 20% 15%, #54d49b 0, #54d49b 17%, transparent 18%),
            radial-gradient(circle at 50% 10%, #405a67 0, #405a67 30%, transparent 31%),
            radial-gradient(circle at 76% 18%, #90afbc 0, #90afbc 19%, transparent 20%);
        opacity: 0.95;
    }

    .hero-inner {
        padding: 38px 40px 110px;
        position: relative;
        z-index: 1;
    }

    h1 {
        margin: 0;
        text-align: center;
        font-size: 54px;
        letter-spacing: 2px;
    }

    .subtitle {
        text-align: center;
        margin: 10px 0 26px;
        font-size: 18px;
        color: #445962;
    }

    .nav-links {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        gap: 14px;
        margin-bottom: 30px;
    }

    .nav-links a {
        text-decoration: none;
        color: #274a5c;
        font-weight: bold;
        padding: 8px 12px;
        border-bottom: 2px solid transparent;
    }

    .nav-links a:hover,
    .nav-links a.active {
        border-bottom-color: #274a5c;
    }

    .panel {
        max-width: 820px;
        margin: 0 auto;
        background: rgba(255, 255, 255, 0.9);
        border: 1px solid #c9d8df;
        border-radius: 16px;
        padding: 24px;
    }

    .panel h2 {
        margin-top: 0;
        margin-bottom: 18px;
        font-size: 28px;
        color: #223b4a;
    }

    .panel p,
    .panel li {
        line-height: 1.6;
    }

    .row {
        display: grid;
        grid-template-columns: 220px 1fr;
        gap: 10px;
        align-items: start;
        margin-bottom: 12px;
    }

    label {
        font-weight: bold;
    }

    .required {
        color: #c62828;
    }

    input[type="text"],
    input[type="email"],
    textarea,
    select {
        width: 100%;
        padding: 9px 10px;
        border: 1px solid #a7b8c2;
        border-radius: 6px;
        font-size: 14px;
        background: #fff;
    }

    textarea {
        min-height: 110px;
        resize: vertical;
    }

    .radio-group {
        display: flex;
        flex-wrap: wrap;
        gap: 16px;
        padding-top: 4px;
    }

    .radio-group label {
        font-weight: normal;
    }

    .error {
        grid-column: 2;
        color: #c62828;
        font-size: 13px;
        margin-top: -4px;
    }

    .success {
        max-width: 820px;
        margin: 0 auto 20px;
        padding: 14px 16px;
        border: 1px solid #9bc8a7;
        background: #e9f7ed;
        color: #245d34;
        border-radius: 10px;
        font-weight: bold;
    }

    .message-box {
        background: #f8fbfd;
        border-left: 5px solid #547182;
        padding: 18px 18px 18px 20px;
        line-height: 1.6;
        color: #304651;
    }

    .actions {
        margin-top: 16px;
    }

    input[type="submit"] {
        border: none;
        background: #2e5264;
        color: #fff;
        padding: 11px 24px;
        font-size: 15px;
        border-radius: 6px;
        cursor: pointer;
    }

    input[type="submit"]:hover {
        background: #223f4e;
    }

    @media (max-width: 900px) {
        .row {
            grid-template-columns: 1fr;
        }

        .error {
            grid-column: 1;
        }
    }
</style>
