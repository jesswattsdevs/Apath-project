<?php
$currentPage = "flight";
$leavingFlightNumber = "";
$leavingAirlineName = "";
$leavingDate = "";
$leavingTime = "";

$leavingFlightNumberErr = "";
$leavingAirlineNameErr = "";
$leavingDateErr = "";
$leavingTimeErr = "";
$successMessage = "";

if (($_SERVER["REQUEST_METHOD"] ?? "") === "POST") {
    $leavingFlightNumber = test_input($_POST["leaving_flight_number"] ?? "");
    $leavingAirlineName = test_input($_POST["leaving_airline_name"] ?? "");
    $leavingDate = test_input($_POST["leaving_date"] ?? "");
    $leavingTime = test_input($_POST["leaving_time"] ?? "");
    $hasError = false;

    if ($leavingFlightNumber === "") {
        $leavingFlightNumberErr = "Leaving flight number is required.";
        $hasError = true;
    }

    if ($leavingAirlineName === "") {
        $leavingAirlineNameErr = "Leaving airline name is required.";
        $hasError = true;
    }

    if ($leavingDate === "") {
        $leavingDateErr = "Leaving date is required.";
        $hasError = true;
    }

    if ($leavingTime === "") {
        $leavingTimeErr = "Leaving time is required.";
        $hasError = true;
    }

    if (!$hasError) {
        $successMessage = "Flight information submitted successfully.";
    }
}

function test_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
?>
<html>
<head>
    <title>Lab 7 - Student Flight Information</title>
    <?php include "student_styles.php"; ?>
</head>
<body>
    <div class="page-shell">
        <div class="hero">
            <div class="hero-inner">
                <h1>APATH</h1>
                <p class="subtitle">Student Flight Information</p>
                <?php include "student_nav.php"; ?>
                <?php if ($successMessage !== "") { ?><div class="success"><?php echo $successMessage; ?></div><?php } ?>
                <section class="panel">
                    <h2>Flight Form</h2>
                    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                        <div class="row">
                            <label for="leaving_flight_number">Leaving Flight Number <span class="required">*</span></label>
                            <input type="text" id="leaving_flight_number" name="leaving_flight_number" value="<?php echo $leavingFlightNumber; ?>">
                            <?php if ($leavingFlightNumberErr !== "") { ?><div class="error"><?php echo $leavingFlightNumberErr; ?></div><?php } ?>
                        </div>

                        <div class="row">
                            <label for="leaving_airline_name">Leaving Airline Name <span class="required">*</span></label>
                            <input type="text" id="leaving_airline_name" name="leaving_airline_name" value="<?php echo $leavingAirlineName; ?>">
                            <?php if ($leavingAirlineNameErr !== "") { ?><div class="error"><?php echo $leavingAirlineNameErr; ?></div><?php } ?>
                        </div>

                        <div class="row">
                            <label for="leaving_date">Leaving Date <span class="required">*</span></label>
                            <input type="text" id="leaving_date" name="leaving_date" placeholder="MM/DD/YYYY" value="<?php echo $leavingDate; ?>">
                            <?php if ($leavingDateErr !== "") { ?><div class="error"><?php echo $leavingDateErr; ?></div><?php } ?>
                        </div>

                        <div class="row">
                            <label for="leaving_time">Leaving Time <span class="required">*</span></label>
                            <input type="text" id="leaving_time" name="leaving_time" placeholder="10:30 AM" value="<?php echo $leavingTime; ?>">
                            <?php if ($leavingTimeErr !== "") { ?><div class="error"><?php echo $leavingTimeErr; ?></div><?php } ?>
                        </div>

                        <div class="actions">
                            <input type="submit" value="Submit Flight Information">
                        </div>
                    </form>
                </section>
            </div>
        </div>
    </div>
</body>
</html>
