<?php $currentPage = "home"; ?>
<html>
<head>
    <title>Lab 7 - Student Home</title>
    <?php include "student_styles.php"; ?>
</head>
<body>
    <div class="page-shell">
        <div class="hero">
            <div class="hero-inner">
                <h1>APATH</h1>
                <p class="subtitle">Lab 7 Student Home Page</p>
                <?php include "student_nav.php"; ?>

                <section class="panel">
                    <h2>Welcome to Atlanta Ga</h2>
                    <p>Please complete your personal profile!</p>
                    <ul>
    
                    <li>If you eed airport pickup, please provide your flight information</li>
                    <li>if you need temp housing, please complete the temp housing form.</li>
                    </ul>
                </section>
            </div>
        </div>
    </div>
</body>
</html>
