<?php
$currentPage = $currentPage ?? "";
?>
<div class="nav-links">
    <a href="lab7.php" <?php if ($currentPage === "home") echo 'class="active"'; ?>>Home</a>
    <a href="student_profile.php" <?php if ($currentPage === "profile") echo 'class="active"'; ?>>Personal Profile</a>
    <a href="student_flight.php" <?php if ($currentPage === "flight") echo 'class="active"'; ?>>Flight Information</a>
    <a href="student_temp_housing_need.php" <?php if ($currentPage === "housing") echo 'class="active"'; ?>>Temp Housing Need</a>
    <a href="pickup_information.php" <?php if ($currentPage === "pickup") echo 'class="active"'; ?>>Pickup Information</a>
    <a href="temp_housing_information.php" <?php if ($currentPage === "temp-info") echo 'class="active"'; ?>>Temp Housing Information</a>
</div>
