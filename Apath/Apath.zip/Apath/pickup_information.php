<?php $currentPage = "pickup"; ?>
<html>
<head>
    <title>Lab 7 - Pickup Information</title>
    <?php include "student_styles.php"; ?>
</head>
<body>
    <div class="page-shell">
        <div class="hero">
            <div class="hero-inner">
                <h1>APATH</h1>
                <p class="subtitle">Pickup Information</p>
                <?php include "student_nav.php"; ?>
                <section class="panel">
                    <h2>Airport Pickup Status</h2>
                    <div class="message-box">
                        We are working on finding a volunteer to pick you up from the airport; information will be available later.
                    </div>
                </section>
            </div>
        </div>
    </div>
</body>
</html>
